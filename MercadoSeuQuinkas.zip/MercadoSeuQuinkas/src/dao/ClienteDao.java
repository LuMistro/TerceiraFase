/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import Model.Cliente;
import factory.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Luiza Mistro
 */
public class ClienteDao implements DaoI<Cliente> {

    Connection conexao = Conexao.getConexao();

    public List<Cliente> listar(String orderBy, String ordenacao) {
        String sql = ("Select "
                + " cli.id, cli.nome, cli.cep, cli.datanascimento, cli.cidade_id"
                + " cid.nome as cidade, cid.uf"
                + "  from "
                + "cliente cli"
                + "inner join "
                + "cidade cid on cli.cidade_id = cid.id"
                + "where cli.ativo = 1 and cid.ativo = 1"
                + " order by " + orderBy + " " + ordenacao);
        try {
            PreparedStatement stmt = conexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            List<Cliente> list = new ArrayList<>();
            while (rs.next()) {
                Cliente c = new Cliente();
                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));
                c.setCep(rs.getString("cep"));
                c.setDataNascimento(rs.getDate("dataNascimento"));
                c.getCidade().setId(rs.getInt("cidade_id"));
                c.getCidade().setNome("cidade");
                c.getCidade().setUf(rs.getString("uf"));
                list.add(c);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Cliente> listar() {
        return listar("cli.id", "Desc");
    }

    @Override
    public int cadastrar(Cliente obj) {
        String sql = "Insert into cliente (nome, cep, dataNascimento, cidade_id) values (?,?,?,?)";
        try {
            PreparedStatement stmt = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            stmt.setString(1, obj.getNome());
            stmt.setString(2, obj.getCep());
            stmt.setDate(3, util.ConversorDeData.dataUtilParaSql(obj.getDataNascimento()));
            stmt.setInt(4, obj.getCidade().getId());
            ResultSet rs;
            if (stmt.executeUpdate() > 0) {
                rs = stmt.getGeneratedKeys();
                rs.next();
                return rs.getInt(1);
            } else {
                return 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 1;
    }

    @Override
    public boolean alterar(Cliente obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean deletar(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Cliente lerPorId(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Cliente> pesquisar(String termo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
