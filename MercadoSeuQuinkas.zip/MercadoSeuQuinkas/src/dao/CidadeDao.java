/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import Model.Cidade;
import factory.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Luiza Mistro
 */
public class CidadeDao implements DaoI<Cidade> {

    Connection conexao = Conexao.getConexao();

    public CidadeDao() {
        super();
    }

    @Override
    public List<Cidade> listar() {
        return listar("nome", "asc");
    }

    public List<Cidade> listar(String orderby, String ordenacao) {
        String sql = "Select id, nome, uf from cidade where ativo = 1 order by " + orderby + " " + ordenacao;
        try {
            PreparedStatement stmt = conexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            List<Cidade> list = new ArrayList<>();
            while (rs.next()) {
                Cidade c = new Cidade();
                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));
                c.setUf(rs.getString("uf"));
                list.add(c);

            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int cadastrar(Cidade obj) {
        String sql = "Insert into cidade (nome, uf) values (?,?)";
        try {
            PreparedStatement stmt = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            stmt.setString(1, obj.getNome());
            stmt.setString(2, obj.getUf());
            ResultSet rs;
            if (stmt.executeUpdate() > 0) {
                rs = stmt.getGeneratedKeys();
                rs.next();
                return rs.getInt(1);
            } else {
                return 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 1;
    }

    @Override
    public boolean alterar(Cidade obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean deletar(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Cidade lerPorId(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Cidade> pesquisar(String termo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
