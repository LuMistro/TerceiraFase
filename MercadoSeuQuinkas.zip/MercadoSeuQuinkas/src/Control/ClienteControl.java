/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Model.Cidade;
import Model.Cliente;
import View.CadastroCliente;
import dao.CidadeDao;
import dao.ClienteDao;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import util.ConversorDeData;

/**
 *
 * @author Luiza Mistro
 */
public class ClienteControl {

    private Cliente cliente;
    private List<Cliente> listclientes;
    private ClienteDao clienteDao;
    private CadastroCliente telaCadastro;
    private List<Cidade> cidades;
    private CidadeDao cidadeDao;

    public ClienteControl(CadastroCliente telaCadastro) {
        this.telaCadastro = telaCadastro;
        clienteDao = new ClienteDao();
        cidadeDao = new CidadeDao();
        carregarCidades();
    }
    

    public void cadastrarAction() {
        cliente = new Cliente();
        cliente.setNome(CadastroCliente.tfNome.getText());
        cliente.setCep(CadastroCliente.tfCEP.getText());
        cliente.setDataNascimento(ConversorDeData.dataUsuarioParaBanco(CadastroCliente.tfDataNascimento.getText()));
        cliente.setCidade((Cidade) CadastroCliente.jComboBox1.getSelectedItem());

        //Cadastrar o cliente
        int newIdCliente = clienteDao.cadastrar(cliente);
        if (newIdCliente > 0) {
            cliente.setId(newIdCliente);
            JOptionPane.showMessageDialog(null, " Cliente cadastrado com sucesso", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            limparFormulario();
        } else {
            JOptionPane.showMessageDialog(null, "Falha ao cadastrar cliente", "Mensagem de erro", JOptionPane.ERROR_MESSAGE);
        }
        cliente = null;
    }

    private void carregarCidades() {
        cidades = cidadeDao.listar();
        DefaultComboBoxModel model = new DefaultComboBoxModel(cidades.toArray());
        CadastroCliente.jComboBox1.setModel(model);
        
    }

    private void limparFormulario() {
        CadastroCliente.tfCEP.setText("");
        CadastroCliente.tfNome.setText("");
        CadastroCliente.tfDataNascimento.setText("");
        CadastroCliente.jComboBox1.setSelectedIndex(-1);
    }

}
