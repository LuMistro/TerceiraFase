/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Model.Cidade;
import View.FramePesquisarCidade;
import dao.CidadeDao;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Luiza Mistro
 */
public class PesquisaCidadeControl {

    private FramePesquisarCidade framePesquisarCidade;
    private Cidade cidade;
    private List<Cidade> cidades;
    private CidadeDao cidadeDao;

    public PesquisaCidadeControl(FramePesquisarCidade framePesquisarCidade) {
        this.framePesquisarCidade = framePesquisarCidade;

    }

    public void preencherTabela() {
        cidades = cidadeDao.pesquisar("");
        String[] colunas = {"Nome", "UF"};
        DefaultTableModel model = new DefaultTableModel(colunas, cidades.size());
        framePesquisarCidade.jTable1.setModel(model);
        List<Object> lista = new ArrayList<>();

        System.out.println(cidades.toString());
        for (int i = 0; i < cidades.size(); i++) {
            Cidade c = cidades.get(i);
            cidade = new Cidade(c.getId(), c.getNome(), c.getUf());
            lista.add(cidade);
        }
        model.addRow(lista.toArray());
    }

}
