/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import View.CadastroCliente;
import View.FrameSobre;
import View.Principal;
import java.beans.PropertyVetoException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Luiza Mistro
 */
public class PrincipalControl {

    private CadastroCliente telaCadastroCliente = null;
    boolean TelaCadastroClientefechado = true;
    boolean SobreFechado = true;
    FrameSobre sobre = new FrameSobre();

    public void chamarTelaCadastrarClienteAction() {

        if (telaCadastroCliente == null || TelaCadastroClientefechado == true) {
            telaCadastroCliente = new CadastroCliente();
            Principal.dpPrincipal.add(telaCadastroCliente);
            telaCadastroCliente.show();
            TelaCadastroClientefechado = false;
        }
//        else {
//            TelaCadastroClientefechado = true;
//        }

        if (telaCadastroCliente.isIconifiable()) {
            try {
                TelaCadastroClientefechado = false;
                telaCadastroCliente.setIcon(false);
            } catch (PropertyVetoException ex) {
                Logger.getLogger(PrincipalControl.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    public void chamarTelaSobre() {

        if (sobre == null) { // se tiver nulo chama janela normalmente
            sobre = new FrameSobre();
          Principal.dpPrincipal.add(sobre);
            sobre.setVisible(true);
        } else {//se ele estiver criado
            if (sobre.isVisible()) {
                sobre.pack();//Redimensiona ao Quadro Original
            } else {
                Principal.dpPrincipal.add(sobre);//adiciona frame ao JDesktopPane
                sobre.setVisible(true);
            }
        }

        String texto = "Luiza Mistro\n";
        texto += "18/04/2019\n";
        texto += "Análise e desenvolvimento de sistemas\n";
        texto += "Palhoça";

        sobre.jTextArea2.setText(texto);
        sobre.setVisible(true);
        sobre.toFront();
        sobre.requestFocus();

        TelaCadastroClientefechado = true;

    }

}
